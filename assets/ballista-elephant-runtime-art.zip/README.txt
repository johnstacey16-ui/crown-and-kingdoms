Ballista Elephant runtime art

Upload the two WebP files inside assets/ to the repository assets/ directory on development. The JSON entries in integration/ are reference data, not replacement manifests. Atlas manifests, cache revisions, inventory, and regression expectations must still be updated and tested before deployment. The source action index 12 is provisional until visual review.
